from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, RedirectResponse
from pydantic import BaseModel
from typing import Any, Optional
import time
import uuid

app = FastAPI(
    title="Customer & Account API Security Lab",
    version="1.0.0",
    description="Intentionally insecure training API for an isolated, authorized security lab. Synthetic data only."
)

# SYNTHETIC FIXTURES ONLY. Do not add real customer data or deploy this service with sensitive connectivity.
USERS = {
    "1": {"id": "1", "name": "Avery Example", "email": "avery@example.test", "role": "user", "isAdmin": False, "tenantId": "tenant-a"},
    "2": {"id": "2", "name": "Blair Example", "email": "blair@example.test", "role": "admin", "isAdmin": True, "tenantId": "tenant-b"},
}
ACCOUNTS = {
    "100": {"id": "100", "ownerId": "1", "tenantId": "tenant-a", "balance": 12500, "currency": "USD"},
    "200": {"id": "200", "ownerId": "2", "tenantId": "tenant-b", "balance": 88000, "currency": "USD"},
}
ORDERS = {
    "500": {"id": "500", "userId": "1", "total": 19.99, "items": ["demo-widget"]},
    "600": {"id": "600", "userId": "2", "total": 799.00, "items": ["demo-laptop"]},
}
TOKENS = {"demo-user-token": "1", "demo-admin-token": "2"}
COMMENTS = []
COUPONS = {"DEMO-ONCE": {"discount": 10, "redeemed": False}}
REPORT = {"generatedAt": "2026-01-01T00:00:00Z", "customers": 2, "internalNote": "SYNTHETIC-TRAINING-DATA"}
START = time.time()

def current_user(request: Request):
    auth = request.headers.get("authorization", "")
    token = auth.removeprefix("Bearer ").strip()
    return TOKENS.get(token)

def obj(data: Any):
    return JSONResponse(content=data)

class LoginBody(BaseModel):
    email: str
    password: str

class GenericBody(BaseModel):
    data: dict[str, Any] = {}

@app.get("/")
def root():
    return {"service": "Customer & Account API Security Lab", "docs": "/docs", "openapi": "/openapi.json",
            "warning": "Isolated training lab only; synthetic fixtures; do not expose sensitive systems."}

# 1
@app.post("/identity/auth/login")
def login(body: LoginBody):
    # Deliberately weak demo authentication: predictable tokens and verbose errors.
    if body.email == "avery@example.test" and body.password == "demo123":
        return {"access_token": "demo-user-token", "token_type": "bearer", "role": "user"}
    if body.email == "blair@example.test" and body.password == "admin123":
        return {"access_token": "demo-admin-token", "token_type": "bearer", "role": "admin"}
    return JSONResponse(status_code=401, content={"error": "Invalid password for supplied account", "hint": "Training lab uses demo credentials"})

# 2
@app.post("/identity/auth/refresh")
def refresh(request: Request):
    # No real refresh-token rotation; returns a predictable training token.
    user = current_user(request)
    return {"access_token": "demo-user-token" if user != "2" else "demo-admin-token", "refresh": "static-demo-refresh-token"}

# 3
@app.post("/identity/auth/logout")
def logout():
    # Token is not revoked in this lab scenario.
    return {"message": "Logged out (training simulation); token remains valid"}

# 4
@app.post("/identity/users")
async def register(request: Request):
    body = await request.json()
    uid = str(max(map(int, USERS.keys())) + 1)
    # Deliberately accepts caller-supplied privileged properties.
    record = {"id": uid, **body}
    USERS[uid] = record
    return JSONResponse(status_code=201, content=record)

# 5
@app.get("/identity/users/me")
def me(request: Request):
    uid = current_user(request) or "1"
    return USERS.get(uid, USERS["1"])

# 6
@app.get("/identity/users/{userId}")
def get_user(userId: str):
    # BOLA: no identity/ownership check.
    return USERS.get(userId, {"error": "user not found"})

# 7
@app.patch("/identity/users/{userId}")
async def patch_user(userId: str, request: Request):
    body = await request.json()
    # Mass assignment / BOPLA: privileged fields are not filtered.
    USERS.setdefault(userId, {"id": userId}).update(body)
    return USERS[userId]

# 8
@app.get("/accounts/{accountId}")
def get_account(accountId: str):
    # BOLA: any caller can read any synthetic account.
    return ACCOUNTS.get(accountId, {"error": "account not found"})

# 9
@app.get("/accounts/{accountId}/transactions")
def transactions(accountId: str):
    # Excessive data exposure and missing ownership check.
    return {"accountId": accountId, "transactions": [
        {"id": "tx-demo-1", "amount": 1200, "merchant": "Example Store", "internalRiskScore": 87},
        {"id": "tx-demo-2", "amount": -42, "merchant": "Coffee Example", "internalRiskScore": 12}
    ]}

# 10
@app.post("/accounts/{accountId}/transfer")
async def transfer(accountId: str, request: Request):
    body = await request.json()
    # No auth, ownership, balance, or idempotency enforcement; synthetic no-op.
    return {"accepted": True, "accountId": accountId, "amount": body.get("amount", 1),
            "destination": body.get("destination", "200"), "message": "SIMULATED ONLY - no funds move"}

# 11
@app.get("/orders/{orderId}")
def get_order(orderId: str):
    # BOLA: no order owner validation.
    return ORDERS.get(orderId, {"error": "order not found"})

# 12
@app.get("/orders")
def list_orders(request: Request):
    # Missing per-user scoping.
    return list(ORDERS.values())

# 13
@app.post("/orders")
async def create_order(request: Request):
    body = await request.json()
    # Trusts client-supplied price and total, but does not perform any real purchase.
    return {"orderId": str(uuid.uuid4()), "accepted": True, "clientSuppliedFields": body,
            "message": "SIMULATED ONLY - no payment or fulfillment"}

# 14
@app.post("/coupons/{couponCode}/redeem")
def redeem_coupon(couponCode: str):
    # Race-condition/single-use weakness represented with synthetic coupon state.
    coupon = COUPONS.get(couponCode)
    if not coupon:
        return JSONResponse(status_code=404, content={"error": "coupon not found"})
    coupon["redeemed"] = True
    return {"coupon": couponCode, "discount": coupon["discount"], "redeemed": True}

# 15
@app.get("/products")
def products():
    return [{"id": "p1", "name": "Demo Widget", "price": 19.99, "supplierInternalCode": "SUP-SECRET-01"},
            {"id": "p2", "name": "Demo Laptop", "price": 799.00, "supplierInternalCode": "SUP-SECRET-02"}]

# 16
@app.get("/products/{productId}")
def product(productId: str):
    return {"id": productId, "name": "Demo Product", "price": 19.99, "internalMargin": 0.62, "supplier": "Example Supplier"}

# 17
@app.get("/search")
def search(q: str = ""):
    # Simulated injection surface: echoes input and flags suspicious syntax without executing it.
    suspicious = any(x in q.lower() for x in ["'", '"', " or ", "--", ";"])
    return {"query": q, "matched": [], "trainingSignal": "query-syntax-not-filtered" if suspicious else "normal"}

# 18
@app.post("/search/filters")
async def filters(request: Request):
    body = await request.json()
    # Accepts arbitrary operators/fields; no database query is executed.
    return {"acceptedFilter": body, "validation": "not-strictly-enforced", "results": []}

# 19
@app.post("/webhooks/validate")
async def webhook_validate(request: Request):
    body = await request.json()
    url = str(body.get("url", ""))
    # SSRF risk surface simulated without making outbound network requests.
    risky = any(host in url.lower() for host in ["localhost", "127.0.0.1", "169.254.169.254", "10.", "192.168."])
    return {"url": url, "wouldRequireBlocking": risky, "note": "Simulation only; server does not fetch the URL"}

# 20
@app.post("/files")
async def upload_metadata(request: Request):
    body = await request.json()
    # Metadata-only upload simulation; does not write files to disk.
    return {"fileId": str(uuid.uuid4()), "filename": body.get("filename", "demo.txt"),
            "contentType": body.get("contentType", "text/plain"), "accepted": True,
            "note": "Metadata simulation only; no file is stored or executed"}

# 21
@app.get("/files/{fileId}")
def download_metadata(fileId: str):
    # Missing object-level access check; synthetic metadata only.
    return {"fileId": fileId, "filename": "sample.txt", "content": "synthetic file content", "ownerId": "2"}

# 22
@app.post("/documents/preview")
async def preview(request: Request):
    body = await request.json()
    # Template injection represented as unescaped preview text; no template engine is evaluated.
    return {"preview": str(body.get("text", "")), "renderMode": "raw-text-simulation"}

# 23
@app.post("/imports/xml")
async def import_xml(request: Request):
    body = await request.json()
    # XML parser is not invoked; exposes a testable unsafe-parser configuration signal.
    return {"accepted": True, "contentLength": len(str(body.get("xml", ""))),
            "parserConfig": {"externalEntities": "not-configured-in-simulation"}}

# 24
@app.get("/diagnostics/health")
def health():
    return {"status": "ok", "uptimeSeconds": int(time.time()-START), "framework": "FastAPI", "debug": True,
            "build": "training-build-2026.10", "environment": "lab"}

# 25
@app.get("/diagnostics/config")
def config():
    # Synthetic configuration disclosure only; no real secrets.
    return {"debug": True, "environment": "lab", "apiKey": "SYNTHETIC-NOT-A-REAL-SECRET", "database": "in-memory-demo"}

# 26
@app.get("/reports/export")
def report_export():
    # No auth or scope check; only synthetic aggregate report.
    return REPORT

# 27
@app.get("/tenants/{tenantId}/settings")
def tenant_settings(tenantId: str):
    # Missing tenant authorization check.
    return {"tenantId": tenantId, "settings": {"billingPlan": "enterprise", "internalFeatureFlag": True}}

# 28
@app.post("/batch")
async def batch(request: Request):
    body = await request.json()
    items = body.get("items", []) if isinstance(body, dict) else []
    # No enforced max batch size in this toy app; only returns count and does not process work.
    return {"accepted": True, "itemCount": len(items), "processed": 0, "note": "No batch work is executed"}

# 29
@app.get("/legacy/v1/customers")
def legacy_customers():
    return {"version": "v1-deprecated", "customers": list(USERS.values()), "deprecated": True}

# 30
@app.post("/comments")
async def create_comment(request: Request):
    body = await request.json()
    comment = {"id": len(COMMENTS)+1, "comment": str(body.get("comment", "")), "author": "anonymous"}
    COMMENTS.append(comment)
    # Stored XSS risk surface: raw text is returned; no HTML is rendered by this API.
    return comment

@app.get("/comments")
def list_comments():
    return COMMENTS

@app.get("/_lab/credentials")
def lab_credentials():
    return {"user": {"email": "avery@example.test", "password": "demo123"},
            "admin": {"email": "blair@example.test", "password": "admin123"},
            "note": "Synthetic credentials for isolated training only."}
